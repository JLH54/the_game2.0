#include <Windows.h>
#include <stdlib.h>
#include <time.h>
#include "Game.h"

int WINAPI WinMain(_In_ HINSTANCE, _In_opt_  HINSTANCE, _In_ LPSTR, _In_ int)
{
    srand((unsigned int)time(NULL));

	Game theGame;
	if (theGame.Init("Demo", 600, 800))
	{
		theGame.Start();
	}

    return 0;
}